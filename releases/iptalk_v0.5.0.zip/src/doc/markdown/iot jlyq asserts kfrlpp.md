# 一、问题 #
后端工程 iot_combination (以下简称 iot) 中的前端资源 asserts 经常在拉取时发生大量冲突。  

**原因**  
1. 在修改 iot 时可能会同时修改前端工程 stwebfontend (以下简称 fe) 并生成新的 asserts；  
2. 新的 asserts 往往与原有 asserts 存在大量冲突，就算 fe 只有少量修改，这是 webpack 打包机制所致。

# 二、方法 #
## 1. 忽略 asserts ##
**操作**  
1)  把 asserts 加入 gitignore。这样在拉取 iot 时 asserts 不会有任何冲突；  
2)  iot 所需的 asserts 永远是最新的 fe 生成的 asserts。

**优点**  
1)  操作简单。  

**缺点**  
1)  某个版本的 iot 使用的最新 fe 生成的 asserts 里可能包含没有对应后端支持的前端功能 (因为前后端分离, 前端开发和后端开发往往是不同步的)；  
2)  发布版本往往是通过取得某个版本的 iot 来生成. 这样就导致发布版本包含了尚未完善的前端功能。

## 2. 控制 asserts ##

**步骤**  
1). iot 仍然对 asserts 采取版本控制；  
2). pull iot 前先把本地的 asserts 删除, 以避免大量冲突；  
3). pull iot 时出现 asserts 冲突一律采用远端内容；  
4). pull iot 后, 修改 iot 的过程中可能会出现需要同时修改 fe 的情况，这时把修改后的 fe 生成的 asserts 替换 iot 当前的 asserts；  
5). push iot 前, 先把当前的 asserts 更名, 这样相当于删除了 asserts；  
6). 再 pull iot，因为本地 asserts 已经删除，所以不会与远端 asserts 冲突；  
7). 再把远端放在本地的 asserts 删除, 原来更名的 asserts 再更名为 asserts；  
8). push iot -force 强制覆盖远端 asserts。  

**优点**  
1)  解决了方案一的缺点。  

**缺点**  
1)  操作繁琐。

# 三、结论 #
第一种方法在发布版本时会造成不便和混乱。第二种方法避免了第一种方法的缺点，虽然使用较为繁琐，但可以考虑做成脚本，一键运行。  
综上，使用第二种方法。