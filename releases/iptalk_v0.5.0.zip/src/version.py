__author__ = 'Administrator'
Version = {
    "iptalk": "v0.5.0"
}
