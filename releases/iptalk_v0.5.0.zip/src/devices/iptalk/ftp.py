import sys,os
from twisted.protocols import ftp
from twisted.internet import defer
from twisted.cred import portal, checkers
from zope.interface import implements
from twisted.python import filepath
from const import FTP_ROOT, FTP_UPGRADE_ROOT, FTP_AD_ROOT, FTP_REC_ROOT

# from utils.platform_wrapper import platform_is

# if platform_is("raspbian"):
#     FTP_ROOT = "/mnt/ftproot/"
# else:
#     FTP_ROOT = sys.path[0] + "/data/ftp/"
# FTP_UPGRADE_ROOT = FTP_ROOT + "Upgrade/"
# FTP_AD_ROOT = FTP_ROOT + "Advertising/"
# FTP_REC_ROOT = FTP_ROOT + "Record/"

FTP_ROOT = FTP_ROOT
FTP_UPGRADE_ROOT = FTP_UPGRADE_ROOT
FTP_AD_ROOT = FTP_AD_ROOT
FTP_REC_ROOT = FTP_REC_ROOT

DATA_CNX_ALREADY_OPEN_START_XFR = "150 Data connection already open, starting transfer"


class MyFTPRealm:
    implements(portal.IRealm)

    def __init__(self):
        # FTP_ROOT = sys.path[0] + "/data/ftp"
        self.anonymousRoot = filepath.FilePath(FTP_ROOT)
        self.dir = {'zhdp': FTP_ROOT}

    def requestAvatar(self, avatarId, mind, *interfaces):
        for iface in interfaces:
            if iface is ftp.IFTPShell:
                if avatarId is checkers.ANONYMOUS:
                    avatar = ftp.FTPAnonymousShell(self.anonymousRoot)
                else:
                    user_dir = self.dir[avatarId]
                    avatar = ftp.FTPShell(filepath.FilePath(user_dir))
                return ftp.IFTPShell, avatar, getattr(avatar, 'logout', lambda: None)
        raise NotImplementedError("Only IFTPShell interface is supported by this realm")


class MyFTP(ftp.FTP):
    def processCommand(self, cmd, *params):

        def call_ftp_command(command):
            method = getattr(self, "ftp_" + command, None)
            if method is not None:
                if command == "PASV":
                    return self.ftp_PASV()
                return method(*params)
            return defer.fail(ftp.CmdNotImplementedError(command))

        cmd = cmd.upper()
        temp = []
        for p in params:
            temp.append(p.replace('\\', '/'))
        params = tuple(temp)

        if cmd in self.PUBLIC_COMMANDS:
            return call_ftp_command(cmd)

        elif self.state == self.UNAUTH:
            if cmd == 'USER':
                return self.ftp_USER(*params)
            elif cmd == 'PASS':
                return ftp.BAD_CMD_SEQ, "USER required before PASS"
            else:
                return ftp.NOT_LOGGED_IN

        elif self.state == self.INAUTH:
            if cmd == 'PASS':
                return self.ftp_PASS(*params)
            else:
                return ftp.BAD_CMD_SEQ, "PASS required after USER"

        elif self.state == self.AUTHED:
            return call_ftp_command(cmd)

        elif self.state == self.RENAMING:
            if cmd == 'RNTO':
                return self.ftp_RNTO(*params)
            else:
                return ftp.BAD_CMD_SEQ, "RNTO required after RNFR"

    def ftp_OPTS(self, option):
        return self.sendLine('200 OK')

    def ftp_APPE(self, path):
        return self.ftp_STOR(path)

    def ftp_STOR(self, path):
        if self.dtpInstance is None:
            raise ftp.BadCmdSequenceError('PORT or PASV required before STOR')

        try:
            newsegs = ftp.toSegments(self.workingDirectory, path)
        except ftp.InvalidPath:
            return defer.fail(ftp.FileNotFoundError(path))
        self.setTimeout(None)

        def enableTimeout(result):
            self.setTimeout(self.factory.timeOut)
            return result

        def cbOpened(file):
            d = file.receive()
            d.addCallback(cbConsumer)
            d.addCallback(lambda ignored: file.close())
            d.addCallbacks(cbSent, ebSent)
            return d

        def ebOpened(err):
            if isinstance(err.value, ftp.FTPCmdError):
                return (err.value.errorCode, '/'.join(newsegs))
            return (ftp.FILE_NOT_FOUND, '/'.join(newsegs))

        def cbConsumer(cons):
            if not self.binary:
                cons = ftp.ASCIIConsumerWrapper(cons)
            d = self.dtpInstance.registerConsumer(cons)
            if self.dtpInstance.isConnected:
                self.sendLine(DATA_CNX_ALREADY_OPEN_START_XFR)
            else:
                self.reply(ftp.FILE_STATUS_OK_OPEN_DATA_CNX)
            return d

        def cbSent(result):
            return (ftp.TXFR_COMPLETE_OK,)

        def ebSent(err):
            if err.check(ftp.FTPCmdError):
                return err
            return (ftp.CNX_CLOSED_TXFR_ABORTED,)

        d = self.shell.openForWriting(newsegs)
        d.addCallbacks(cbOpened, ebOpened)
        d.addBoth(enableTimeout)
        return d

    def ftp_RETR(self, path):
        if self.dtpInstance is None:
            raise ftp.BadCmdSequenceError('PORT or PASV required before RETR')

        try:
            newsegs = ftp.toSegments(self.workingDirectory, path)
        except ftp.InvalidPath:
            return defer.fail(ftp.FileNotFoundError(path))
        self.setTimeout(None)

        def enableTimeout(result):
            self.setTimeout(self.factory.timeOut)
            return result

        if not self.binary:
            cons = ftp.ASCIIConsumerWrapper(self.dtpInstance)
        else:
            cons = self.dtpInstance

        def cbSent(result):
            return (ftp.TXFR_COMPLETE_OK,)

        def ebSent(err):
            if err.check(ftp.FTPCmdError):
                return err
            return (ftp.CNX_CLOSED_TXFR_ABORTED,)

        def cbOpened(file):
            if self.dtpInstance.isConnected:
                self.sendLine(DATA_CNX_ALREADY_OPEN_START_XFR)
            else:
                self.reply(ftp.FILE_STATUS_OK_OPEN_DATA_CNX)

            d = file.send(cons)
            d.addCallbacks(cbSent, ebSent)
            return d

        def ebOpened(err):
            if not err.check(ftp.PermissionDeniedError, ftp.FileNotFoundError, ftp.IsADirectoryError):
                pass
            if err.check(ftp.FTPCmdError):
                return (err.value.errorCode, '/'.join(newsegs))
            return (ftp.FILE_NOT_FOUND, '/'.join(newsegs))

        d = self.shell.openForReading(newsegs)
        d.addCallbacks(cbOpened, ebOpened)
        d.addBoth(enableTimeout)
        return d


class MyFTPFactory(ftp.FTPFactory):
    port = 21
    protocol = MyFTP

    def __init__(self):
        p = portal.Portal(MyFTPRealm())
        file_name = sys.path[0] + "/devices/iptalk/ftp.db"
        p.registerChecker(checkers.FilePasswordDB(file_name))
        self.portal = p
        self.userAnonymous = 'anonymous'
        self.instances = []
        self.makeFtpDir()

    def makeFtpDir(self):
        ftpfolder = os.path.join(os.path.abspath(os.path.dirname(__file__) + os.path.sep + ".."+ os.path.sep + ".."), "data", "ftp")
        if not os.path.exists(ftpfolder):
            os.makedirs(ftpfolder)
            os.makedirs(os.path.join(ftpfolder,"Advertising"))
            os.makedirs(os.path.join(ftpfolder, "Alram"))
            os.makedirs(os.path.join(ftpfolder, "Broadcast"))
            os.makedirs(os.path.join(ftpfolder, "Record"))
            os.makedirs(os.path.join(ftpfolder, "Upgrade"))
            os.makedirs(os.path.join(ftpfolder, "VoiceBroadcast"))

