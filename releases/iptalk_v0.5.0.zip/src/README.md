# 美一物联网平台SmartTalk核心组件IoTService


## 技术要点

1. 基于Twisted异步网络框架
2. 基于Hprose RPC框架


## 功能特性

1. 支持多协议自动识别
2. 支持MQTT物联网协议