# -*- coding:utf-8 -*-
__author__ = 'zhwx'



class Manager(object):
    """
        网元管理对象，单例实例
        用来管理整个系统的所有网元对象
    """
    def add_element(self):
        pass

