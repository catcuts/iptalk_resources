# -*- coding: utf-8 -*-
__author__ = 'ZhangWeiXiong,wxzhang@126.com'

def site_cache(cls):
    """ 用来对site handler进行修改 """
    pass



def cache_content(key_prefix,key,timeout):
    """ 用来进行缓存 """
    pass



