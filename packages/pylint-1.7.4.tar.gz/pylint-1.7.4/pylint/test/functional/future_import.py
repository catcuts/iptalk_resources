"""a docstring"""

from __future__ import generators
