"""Checks import position rule"""
# pylint: disable=unused-import,pointless-string-statement
"Two string"

import os  # [wrong-import-position]
