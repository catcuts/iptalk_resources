"""
Test for issue ##1139 - when CRLF newline characters are used,
\r is left in msg section. As a result, output line in cmdline
is overwritten with text after msg"""

# TODO Lorem ipsum dolor sit amet consectetur adipiscing elit  # [fixme]
