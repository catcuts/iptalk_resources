# pylint: disable=missing-docstring, unused-variable, pointless-statement, too-few-public-methods

class WrapperClass(object):
    def method(self):
        var = +4294967296
        self.method.__code__.co_consts
