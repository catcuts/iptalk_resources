def toto # [syntax-error]
