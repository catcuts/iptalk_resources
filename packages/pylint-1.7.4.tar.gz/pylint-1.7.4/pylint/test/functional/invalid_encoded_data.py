# coding: utf-8
"""Test data file with encoding errors."""


STR = 'Су�ествительное'  # [invalid-encoded-data]
