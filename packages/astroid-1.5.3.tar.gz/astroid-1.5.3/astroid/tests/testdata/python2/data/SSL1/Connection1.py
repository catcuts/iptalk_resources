"""M2Crypto.SSL.Connection

Copyright (c) 1999-2004 Ng Pheng Siong. All rights reserved."""
from __future__ import print_function
RCS_id='$Id: Connection1.py,v 1.1 2005-06-13 20:55:22 syt Exp $'

#Some code deleted here

class Connection:

    """An SSL connection."""

    def __init__(self, ctx, sock=None):
        print('init Connection')
